mpirun -np 12  ~/2022_honpas/honpas_v1.1/Obj/siesta <ZnO.fdf |tee out
